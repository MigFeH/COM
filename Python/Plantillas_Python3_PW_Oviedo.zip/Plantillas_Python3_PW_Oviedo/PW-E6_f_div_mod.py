def succ(Z):
    return Z + 1
def pred(Z): 
    if Z >= 1:
        return Z - 1
    else:
        return 0
		
""" PW-E6-f): Construir un PW que compute f(X,Y)=Y div (X mod Y). No se permite emplear macros. """ 
# Pasar a f como argumento las k varibles (X1, X2, ...Xk)  del programa while k variables construido
def pw(...):


    return X1

def div_mod(X,Y):
  return print(pw(X,Y,....))


# Para probar el programa, invocar div_mod
# Probar que sucede para varios valores de X e Y: 0, 1, 2, ...
# Probar que cuando Y==0 --> Indeterminacion
div_mod(....)	


