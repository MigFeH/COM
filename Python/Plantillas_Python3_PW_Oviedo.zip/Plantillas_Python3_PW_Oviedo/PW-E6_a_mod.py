def succ(Z):
    return Z + 1
def pred(Z): 
    if Z >= 1:
        return Z - 1
    else:
        return 0

""" PW-E6-a): Construir un PW que compute f(X,Y)=X mod Y, sin utilizar macros """ 
# Pasar a f como argumento las k varibles (X1, X2, ...Xk) del programa while k variables construido
def pw(...):


    return X1

def mod(X,Y):
  return print(pw(X,Y,...))

# Para probar el programa, invocar a mod
# Probar que sucede para varios valores de X e Y. 
# Probar que cuando Y==0 --> Indeterminacion
mod(...)
#mod(4,2)
#mod(5,2)

