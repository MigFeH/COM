def succ(Z):
    return Z + 1
def pred(Z): 
    if Z >= 1:
        return Z - 1
    else:
        return 0

""" PW-E2: Construir un PW equivalente a este sin macros
begin 
X2=2;
while X3!=0 do
begin
  X2=X2+X4;
  X3=pred(X3);
end
X1=X2;
end
"""

# Pasar a pw como argumento las k varibles (X1, X2, ...Xk) del programa while k variables construido
def pw(...):

    return X1

# Para probar el programa, invocar el main con k argumentos
print(pw(...))
